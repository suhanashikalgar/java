/**
 * 
 */
/**
 * 
 */
module Test_paper {
}