package com.dkte;
import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc = new Scanner(System.in);
   
    Staff[] stf =  new Staff[10];
    int counter=0;
    
    while(true) {
    	System.out.println();
    	System.out.println("1. Add Teaching staff.");
    	System.out.println("2. Add Lab staff.");
    	System.out.println("3. Display all Teaching staff.");
    	System.out.println("4. Display All Lab staff.");
    	System.out.println("5. Find specific teaching staff.");
    	System.out.println("6. Find specific lab staff.");
    	System.out.println("7. Display teaching staff who worked for highest hours");
    	System.out.println("8. Display lab staff who have lowest salary");
    	System.out.println("9. Exit");
    	
    	System.out.print("Enter Your Choice:");
    	int ch=sc.nextInt();
    	switch(ch) {
    	case 1:
    		if(counter < stf.length) {
				
				stf[counter]=new TeachingStaff();
				stf[counter].accept();
				counter++;
			}
			else System.out.println(" Teaching staff can not be added");
			break;

    	case 2:
    		if(counter < stf.length) {
				
				stf[counter]=new LabStaff();
				stf[counter].accept();
				counter++;
			}
			else System.out.println("Employee full");
			break;

            
    	case 3:
    		for (int i = 0; i < counter; i++) {
                System.out.println("\nEmployee " + (i + 1) + ":\n" + stf[i]);
            }
            break;
    	case 4:
    		
    		break;
    	case 5:
    		
    		System.out.print("Enter  ID to search: ");
            int searchId = sc.nextInt();
            boolean found = false;
            for (int i = 0; i < counter; i++) {
                if (stf[i].getId() == searchId) {
                    System.out.println(" Staff Found \n" + stf[i]);
                    found = true;
                    break;
                }
                else {
                	System.out.println("Staff not found\n");
                	
                }
                
            }	
            
            break;
    	case 6:
            
    		
            break;
    	case 7:
    	   
    	   break;
    	case 8:
    		break;
    	case 9:
    		System.out.println("Exit application");
     	   System.exit(0);
     	  
    		break;
    	default :
    		System.out.println("Invalid Choice");
    	}
    }
	}

}
